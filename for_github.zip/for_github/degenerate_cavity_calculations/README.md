# degenerate_cavity_calculations
Codes for the calculation of the electromagnetic field propagation inside a degenerate optical cavity, using the angular spectrum propagation method
