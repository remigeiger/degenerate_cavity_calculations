from distutils.core import setup

setup(name='efield',
      version='0.1',
      packages=['efield'])