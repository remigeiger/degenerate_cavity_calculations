from distutils.core import setup

setup(name='fftcavity1d',
      version='0.1')